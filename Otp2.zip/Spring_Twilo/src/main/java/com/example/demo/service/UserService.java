package com.example.demo.service;

public interface UserService {
	public String generateOTP(String Username);
}